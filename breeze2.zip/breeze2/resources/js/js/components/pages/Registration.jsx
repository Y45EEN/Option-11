import { Container, Form, Button, Row, Col } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import React, { Component } from 'react';
import axios from "axios";

class Registration extends Component {
  constructor(props) {
    super(props);

    this.state = {
      firstname: '',
      lastname: '',
      email: '',
      phone: '',
      password: '',
      password_confirmation: '', // Match the variable name here
    };
    

    this.firstName = this.firstName.bind(this);
    this.lastName = this.lastName.bind(this);
    this.takePhone = this.takePhone.bind(this);
    this.takeEmail = this.takeEmail.bind(this);
    this.takePassword = this.takePassword.bind(this);
    this.takeConfirmPassword = this.takeConfirmPassword.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  firstName(event) {
    this.setState({ firstname: event.target.value });
  }

  lastName(event) {
    this.setState({ lastname: event.target.value });
  }

  takePhone(event) {
    this.setState({ phone: event.target.value });
  }

  takeEmail(event) {
    this.setState({ email: event.target.value });
  }

  takePassword(event) {
    this.setState({ password: event.target.value });
  }

  takeConfirmPassword(event) {
    this.setState({ password_confirmation: event.target.value });
  }

  handleSubmit(event) {
    event.preventDefault(); // Prevent the default form submission behavior

    const packets = {
      firstname: this.state.firstname,
      lastname: this.state.lastname,
      email: this.state.email,
      phone: this.state.phone,
      password: this.state.password,
      password_confirmation: this.state.password_confirmation, // Match the variable name here
    };
    

    axios.post('/register', packets)
      .then(response => alert(JSON.stringify(response.data)))
      .catch(error => {
        console.log("ERROR:: ", error.response.data);
      });
  }

  render() {
    return (
      <Container
        className='d-flex align-items-center justify-content-center '
        style={{ minHeight: '75vh' }}
      >
        <Form className='p-5 rounded shadow-sm bg-dark text-light'>
          <h2 className='text-center mb-4 pt-4'>Create Account</h2>

          <Row className='mb-3'>
            <Col md={6} className='pr-md-2'>
              <Form.Group controlId='formBasicFirstName'>
                <Form.Label>First name</Form.Label>
                <Form.Control type='text' placeholder='Enter first name' onChange={this.firstName} />
              </Form.Group>
            </Col>
            <Col md={6} className='pl-md-2'>
              <Form.Group controlId='formBasicLastName'>
                <Form.Label>Last name</Form.Label>
                <Form.Control type='text' placeholder='Enter last name' onChange={this.lastName} />
              </Form.Group>
            </Col>
          </Row>

          <Row className='mb-3'>
            <Col md={6} className='pr-md-2'>
              <Form.Group controlId='formBasicEmail'>
                <Form.Label>Email address</Form.Label>
                <Form.Control type='email' placeholder='Enter email' onChange={this.takeEmail} />
              </Form.Group>
            </Col>
            <Col md={6} className='pr-md-2'>
              <Form.Group controlId='formBasicPhoneNumber'>
                <Form.Label>Phone Number</Form.Label>
                <Form.Control type='number' placeholder='Enter phone number' onChange={this.takePhone} />
              </Form.Group>
            </Col>
          </Row>

          <Row className='mb-3'>
            <Col md={6} className='pr-md-2'>
              <Form.Group controlId='formBasicPassword'>
                <Form.Label>Password</Form.Label>
                <Form.Control type='password' placeholder='Password' onChange={this.takePassword} />
              </Form.Group>
            </Col>
            <Col md={6} className='pl-md-2'>
              <Form.Group controlId='formBasicConfirmPassword'>
                <Form.Label>Confirm password</Form.Label>
                <Form.Control type='password' placeholder='Confirm Password' onChange={this.takeConfirmPassword} />
              </Form.Group>
            </Col>

          </Row>

          <Button variant='primary' type='submit' className='w-100 mt-3 mb-5'>
            Sign-up
          </Button>
          <Link to={`/login`} className='link-info text-center'>
            Already Registered? Click here to login!
          </Link>
        </Form>
      </Container>
    );
  }
}

export default Registration;

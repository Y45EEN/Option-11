<?php

use App\Http\Controllers\ManageAccount;
use App\Http\Controllers\ManageBasketController;
use App\Http\Controllers\ShowBikesController;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PaymentDetails;
use Inertia\Inertia;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return Inertia::render('Welcome', [
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'laravelVersion' => Application::VERSION,
        'phpVersion' => PHP_VERSION,
    ]);
});

Route::get('/updateAccount', function () {

   
    
    return Inertia::render('UpdateAccount');
})->middleware(['auth', 'verified'])->name('updateAccount');




Route::get('/BikeProducts', [ShowBikesController::class, 'showAll'])->name('products');

Route::get('/AccessoryProducts', [ShowAccessoriesController::class, 'showAll'])->name('accessoryProducts');

Route::match(['get', 'post'],'/filter/{type}','App\Http\Controllers\ShowBikesController@filter')->name('filter');
Route::post('update', [ManageAccount::class, 'update'])->name('update');





    Route::match(['get', 'post'],'/checkout','App\Http\Controllers\PaymentDetails@payment')->name('checkout');
  



Route::get('/dashboard', function () {
    return Inertia::render('Dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');





Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    Route::get('deleteAccount', [ManageAccount::class, 'destroy'])
    ->name('deleteAccount');
    Route::get('/basket', [ManageBasketController::class, 'search'])->name('basket');
    Route::post('/addBasket', [ShowBikesController::class, 'addBasket'])->name('addBasket');
    Route::post('/addPayment', [PaymentDetails::class, 'addPayment'])->name('addPayment');
    Route::post('/addPayment', [PaymentDetails::class, 'addPayment'])->name('addPayment');
 
    Route::match(['get', 'post'],'/deleteProduct','App\Http\Controllers\ManageBasketController@deleteProduct')->name('deleteProduct');
  
    
});

require __DIR__.'/auth.php';

import React from "react";

const Repair = (repair) => {
    return (
        <div>
            <h1>Repair</h1>
            <p>{repair.status}</p>
        </div>
    );
}

export default Repair;

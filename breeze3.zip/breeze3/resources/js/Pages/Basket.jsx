import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout";
import { Head, useForm, Link } from "@inertiajs/react";
import React, { useState, useEffect } from "react";
import NavBar from "@/Components/NavBar";

export default function Basket({ auth, basket, bikename }) {
    const { data, setData, post } = useForm({
        basketid: null,
    });

    const [quantities, setQuantities] = useState(basket.map(() => 1));

    const handleQuantityChange = (index, newQuantity) => {
        const newQuantities = [...quantities];
        newQuantities[index] = newQuantity;
        setQuantities(newQuantities);
    };

    const handleItemRemove = (e, basketid) => {
        e.preventDefault();
        setData("basketid", basketid);
    };

    useEffect(() => {
        const removeItem = async () => {
            await post("/deleteProduct");
        };

        if (data.basketid !== null) {
            removeItem();
        }
    }, [data.basketid]);

    const calculateTotalPrice = (price, quantity) => {
        return price * quantity;
    };

    return (
        <>
            <NavBar auth={auth} />
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8">
                <Head title="Basket" />
                <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div className="p-6 bg-white border-b border-gray-200">
                        <h2 className="text-2xl font-semibold mb-4">
                            Your Basket
                        </h2>
                        {basket.length > 0 ? (
                            <table className="w-full border-collapse border border-gray-300">
                                <thead>
                                    <tr className="bg-gray-100">
                                        <th className="py-2 px-4 border-b">
                                            Bike Name
                                        </th>
                                        <th className="py-2 px-4 border-b">
                                            Quantity
                                        </th>
                                        <th className="py-2 px-4 border-b">
                                            Total Price
                                        </th>
                                        <th className="py-2 px-4 border-b">
                                            Actions
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {basket.map((item, index) => (
                                        <tr
                                            key={index}
                                            className={
                                                (index + 1) % 2 === 0
                                                    ? "bg-gray-50"
                                                    : ""
                                            }
                                        >
                                            <td className="py-2 px-4 border-b">
                                                {item.bikeid}
                                            </td>
                                            <td className="py-2 px-4 border-b">
                                                <td className="py-2 px-4 border-b">
                                                    {item.quantity}
                                                </td>
                                            </td>
                                            <td className="py-2 px-4 border-b">
                                                {calculateTotalPrice(
                                                    item.totalprice,
                                                    quantities[index]
                                                )}
                                            </td>
                                            <td className="py-2 px-4 border-b">
                                                <form
                                                    onSubmit={(e) =>
                                                        handleItemRemove(
                                                            e,
                                                            item.basketid
                                                        )
                                                    }
                                                >
                                                    <button
                                                        type="submit"
                                                        className="text-red-500 hover:underline"
                                                    >
                                                        Remove
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    ))}

                                    <Link
                                        href={route("checkout")}
                                        className="link-info text-center"
                                    >
                                        Go to checkout
                                    </Link>
                                </tbody>
                            </table>
                        ) : (
                            <p>Your basket is empty.</p>
                        )}
                    </div>
                </div>
            </div>
        </>
    );
}




<?php

namespace App\Http\Controllers;

use App\Models\ProductParts;
use App\Http\Requests\StoreProductPartsRequest;
use App\Http\Requests\UpdateProductPartsRequest;

class ProductPartsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreProductPartsRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(ProductParts $productParts)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(ProductParts $productParts)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateProductPartsRequest $request, ProductParts $productParts)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(ProductParts $productParts)
    {
        //
    }
}

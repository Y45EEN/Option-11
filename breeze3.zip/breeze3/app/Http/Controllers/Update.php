<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Providers\RouteServiceProvider;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules;
use Inertia\Inertia;
use Inertia\Response;







class UpdateProfile extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function update(Request $request): RedirectResponse
    {
        $user = $request->user();
        $userID = $user->userid;

        
            $validateInput = $request->validate([
                'firstname'=>'required',
                'lastname'=>'required',
                'phonenumber'=>'required',
                'email'=>'required',
                'password'=>'required',
                'confirm_password'=>'required'
        
            ]);
        
        
        
           if ($validateInput){
        
           
        
                $update = Projects::where('userid',$userID)->update([
                    'firstname' => $request->firstname,
                    'lastname' => $request->lastname,
                    'phonenumber' => $request->phonenumber,
                    'email' => $request->email,
                    'password' => Hash::make($request->password)
        
        
        
                ]);
                return redirect(RouteServiceProvider::HOME);
        
        
        
           } else {
        
        
            return back()->withErrors($validateInput)->withInput();
           }
        
    
        
        
    }


}

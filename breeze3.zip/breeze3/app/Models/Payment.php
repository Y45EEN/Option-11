<?php

namespace App\Models;



use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class Payment extends Model
{   public $timestamps = false;
    protected $primaryKey = 'payment_id';
    protected $connection = 'mysql';
    protected $fillable = [
        'payment_id',
        'cardNumber',
        'expiryDate',
        'cvv',
        'userid',
       
    ];

  
    
}
